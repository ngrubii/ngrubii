<?php
define('HOST', 'localhost'); // 127.0.0.1
define('DBNAME', 'salesforcebaza'); 
define('USER', 'root');
define('PASS', '');