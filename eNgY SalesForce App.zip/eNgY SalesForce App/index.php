<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Login Page</title>
  <script src="js/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="css/sweetalert2.min.css">
  <!-- MDB icon -->
  <link rel="icon" href="logo.ico" type="image/x-icon" />
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" />
  <!-- MDB -->
  <link rel="stylesheet" href="css/mdb.min.css" />
  <link rel="stylesheet" href="css/style.css" />

</head>

<style>
  
</style>
</head>
<body>
<section class="h-100 gradient-form" style="background-color: #eee;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-10">
        <div class="card rounded-3 text-black">
          <div class="row g-0">
            <div class="col-lg-6">
              <div class="card-body p-md-5 mx-md-4">

                <div class="text-center">
                  <img src="engy.png"
                    style="width: 185px;" alt="logo">
                    <br><br>
                    <h4 class="mt-1 mb-5 pb-1">Welcome Sales Warriors!</h4>
                    <b><p>Please login to your account</p></b>

                </div>

                <form method = "post" action= "logika/prijavise.php">

                  <div class="form-outline mb-4">
                    <input type="text" id="form2Example11" class="form-control" name="username"/>
                    <label class="form-label" for="form2Example11">Username</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" id="form2Example22" class="form-control" name="password" />
                    <label class="form-label" for="form2Example22">Password</label>
                  </div>
<br>
                  <div class="text-center pt-1 mb-5 pb-1">
                  <input type = 'submit'class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3" value="Log in">
                      
                    <a class= "" href="#!" onclick="showAlert()">Forgot password?</a>
                  </div>
                  <?php
                  if(isset($_GET['error'])== true){
                    echo '<div class="alert alert-danger" role="alert">
                    Username or password does not match!
                  </div';
                  }
                  ?>
                 

                </form>

              </div>
            </div>
            <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
              <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                <h4 class="mb-4">“The way to get started is to quit talking and begin doing.” </h4>
                <p class="big mb-0">– Walt Disney</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- 
    <form method = "post" action= "prijavise.php">
        <input type = 'text' name="username" placeholder="Unesite username"><br>
        <input type = 'password' name="password" placeholder="Unesite password"><br>
        <input type = 'submit' value="Prijavi se">
    </form> -->


    
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script type="text/javascript" src="js/loginscript.js"></script>

</body>
</html>