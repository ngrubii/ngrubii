<?php
if (!isset($_POST['username'])) {
    header('Location:../login.php');
    die();
}

$username = $_POST['username'];
$password = $_POST['password'];

require_once __DIR__ . '/../tabele/Korisnik.php';
$korisnik = Korisnik::proveri($username, $password);

if($korisnik == null){

    session_start();
    $_SESSION['korisnik_id'] = $korisnik->id;
    header('Location: ../index.php?error=1');
    die();
}
header('Location:../prijavljen.php');
