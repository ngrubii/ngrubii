<?php 
require_once __DIR__  . '/../config.php';
require_once __DIR__ . '/../includes/Database.php';

class TipKorisnika{
    public $id;
    public $naziv_tipa;
    public $prioritet;
}
