/**
 * Theme: Metrica - Responsive Bootstrap 4 Admin Dashboard
 * Author: Mannatthemes
 * Leads Js
 */

// Datatable
$('#datatable').DataTable();